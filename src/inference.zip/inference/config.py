MODEL_NAME = "DeepPavlov/rubert-base-cased-conversational"
MODEL_MAX_LENGTH = 512
PATH_TO_CHECKPOINT = "/Users/falaputin/virtual_assistant/trucase_project/ru-punctuation-truecase/src/results/02-09-2023-11-01-00/checkpoint-22446"
